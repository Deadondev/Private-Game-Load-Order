Hideous Destructor Addon by Mickromash

Shows ammo, weapons, armor and other handled items on player.

Requires HDest Bubbles Addon
