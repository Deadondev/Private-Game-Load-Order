# HDest Bubbles

Originally made by Josh771, forked by emmy-gote, now maintained by the community.

## What is Hideous Destructor Bubbles?

This add-on makes many of the items in Hideous Destructor float in front of players when they have them equipped.  It optionally also shows that a player is wearing a backpack.  Some of the "bubbles" are even animated when used!

### What has been changed in this fork:

- Updated to target latest HD main
- Added support for WIMP
- Added CVar to allow bubbled weapons to appear to the user
- Added sprite for improvised bandaging.

## Credits

- Backpack Rotations: KDiZD team (artist JoeyTD?)
- Improvised bandaging bubble sprite originally made by Bloodyacid, edited to resemble a gauze roll by Underqualified Gunman .
