# Cozis-Offworld-Wares

A Hideous Destructor addon that adds various offworld items, including Muskets, Magical Rum and more! See our wiki for more in-depth documentation.