# HDest-Re-Enforcements
A beastiary expansion for the GZDoom mod "Hideous Destructor".
