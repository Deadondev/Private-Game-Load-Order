# Melonades (Melodica's Custom Grenades)
Custom grenades for Hideous Destructor.

Has a menu where you can toggle grenade spawns in the wild to your liking. Does not affect appearances in backpacks or ammo boxes.

**Currently adds:**
*  Thunder Grenades **(loadout code THG)**
*  MG13 Grenades from EDF **(loadout code MG3)**
*  A rock **(loadout code STN)**
*  Impact Grenades **(loadout code IMG)**